#region Copyright(C) M.Shams Mukhtar (shams_mukhtar@yahoo.com)
//
// You are free to use or modify the code, as long as you place
// copyright notice above. Thanks!
//
// Filename: MasterPage.cs
#endregion

using System;
using System.Web.UI;

namespace Shams.MVC.WebApp
{
	/// <summary>
	/// Summary description for MasterPage.
	/// </summary>
	public class MasterPage : Shams.Web.UI.MasterPages.MasterPageBase
	{
		public MasterPage()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		override public void AddPlaceHolderControls()
		{	
			ClearPlaceHolderControls();
			base.AddPlaceHolderControls();
		}

		override public void AddPlaceHolderHeader()
		{
			// clear place-holders contents from MasterPageBase(.)
			// ClearPlaceHolderControls();
			//base.userPageControl.PlaceHolderHeader.Controls.Clear();
			System.Web.UI.UserControl userControl = LoadUserControl("WebUserControls/MasterHeaderControl.ascx");
			base.userPageControl.PlaceHolderHeader.Controls.Add(userControl);
		}

		override public void AddPlaceHolderNavigation()
		{
			//System.Web.UI.UserControl userControl = LoadUserControl("WebUserControls/NavigationControl.ascx");
			//base.userPageControl.PlaceHolderNavigation.Controls.Add(userControl);
		}

		override public void AddPlaceHolderLogo()
		{
			System.Web.UI.UserControl userControl = LoadUserControl("WebUserControls/MasterLogoControl.ascx");
			base.userPageControl.PlaceHolderLogo.Controls.Add(userControl);
		}
		override public void AddPlaceHolderContents()
		{
			System.Web.UI.UserControl userControl = LoadUserControl("WebUserControls/MasterContentsControl.ascx");
			base.userPageControl.PlaceHolderContents.Controls.Add(userControl);
		}
	}
}
