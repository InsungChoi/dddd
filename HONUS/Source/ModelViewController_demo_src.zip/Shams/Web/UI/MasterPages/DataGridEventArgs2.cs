#region Copyright(C) M.Shams Mukhtar (shams_mukhtar@yahoo.com)
//
// You are free to use or modify the code, as long as you place
// copyright notice above. Thanks!
//
// Filename: DataGridEventArgs2.cs
#endregion

using System;

namespace Shams.Web.UI.MasterPages
{
	/// <summary>
	/// Summary description for DataGridEventArgs2.
	/// </summary>
	[Serializable()]
	public class DataGridEventArgs2 : EventArgs
	{
		protected object keyObj;

		public DataGridEventArgs2(object keyObj)
		{
			this.keyObj = keyObj;
		}
		
		public object KeyProp
		{
			get
			{
				return keyObj;
			}
			set
			{
				keyObj = value;
			}
		}
	}//;~
}