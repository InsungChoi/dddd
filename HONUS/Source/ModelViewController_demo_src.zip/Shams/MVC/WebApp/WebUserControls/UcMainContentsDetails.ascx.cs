using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using Shams.Web.UI.MasterPages;
using Shams.MVC.WebApp.DataAccess;

namespace Shams.MVC.WebApp.WebUserControls
{
	/// <summary>
	///	Summary description for UcMainContentsDetails(2).
	/// </summary>
	public class UcMainContentsDetails : System.Web.UI.UserControl, Shams.Web.UI.MasterPages.IListner
	{
		protected System.Web.UI.WebControls.DataGrid dtgDetails;
		protected DataView detailsView;

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				if (Cache["ds1"] == null)
				{
					Cache["ds1"] = DataAccessGateway.GetData1();
				}
				dtgDetails.SelectedIndex = 0;
				DetailsSelectedIndexProp = dtgDetails.SelectedIndex;
				DetailsPageIndexProp = 0; 

				// notify for the new selection change...
				dtgDetailsSelectedIndexChanged(dtgDetails, e);
				return;
			}
			dtgDetails.SelectedIndex = DetailsSelectedIndexProp;
			dtgDetails.CurrentPageIndex = DetailsPageIndexProp;	
			BindDetails();	
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender(e);
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.dtgDetails.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.dtgDetailsPageIndexChanged);
			this.dtgDetails.SelectedIndexChanged += new System.EventHandler(this.dtgDetailsSelectedIndexChanged);
			this.Load += new System.EventHandler(this.Page_Load);
			// this.PreRender += new System.EventHandler(this.Page_PreRender);

		}
		#endregion

		#region implementation of IListner
		virtual public void Update(object sender, EventArgs e)
		{
			DetailsSelectedIndexProp = 0;
			DetailsPageIndexProp = 0;

			BindDetails(sender, (DataGridEventArgs2)e);
		}
		#endregion

		[System.Security.Permissions.PermissionSet(System.Security.Permissions.SecurityAction.Demand, Name="FullTrust")] 
		protected override void LoadViewState(object savedState)
		{
			if (savedState != null)
			{
				base.LoadViewState(savedState);
			}
		}

		[System.Security.Permissions.PermissionSet(System.Security.Permissions.SecurityAction.Demand, Name="FullTrust")] 
		protected override object SaveViewState()
		{
			DetailsSelectedIndexProp = dtgDetails.SelectedIndex;
			DetailsPageIndexProp = dtgDetails.CurrentPageIndex;
			return base.SaveViewState();
		}
		private void BindDetails()
		{
			BindDetails(dtgDetails, DataGridEventArgsProp);
		}

		private void BindDetails(object sender, DataGridEventArgs2 args)
		{
			if(args == null) return;

			DataSet ds1 = (DataSet)Cache["ds1"];
			detailsView = new DataView(ds1.Tables[1]);
			string strExpr = "CustomerID= '" + (string)args.KeyProp + "'";

			// Use the Select method to find all rows matching the filter.
			DataGridEventArgsProp = args;
			detailsView.RowFilter = strExpr;

			this.dtgDetails.SelectedIndex = DetailsSelectedIndexProp;
			// the dataGrid CurrentPageIndex value must be >= 0 and < PageCount
			this.dtgDetails.CurrentPageIndex = DetailsPageIndexProp;
			this.dtgDetails.DataSource = detailsView;
			this.dtgDetails.DataBind();
			
			System.Diagnostics.Debug.WriteLine("BindDetails(.) called...");
		}

		private void dtgDetailsSelectedIndexChanged(object sender, System.EventArgs e)
		{
			DataGrid dg = (DataGrid)sender;
			DetailsSelectedIndexProp = dg.SelectedIndex;
			
			// CurrentPageIndex value must be >= 0 and < the PageCount
			BindDetails();
			System.Diagnostics.Debug.WriteLine("(Details)SelectedIndexChanged Event fired..");
		}

		private void dtgDetailsPageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
		{
			DataGrid dg = (DataGrid)source;
			dg.CurrentPageIndex  = e.NewPageIndex;
			DetailsPageIndexProp = e.NewPageIndex;

			// CurrentPageIndex value must be >= 0 and < the PageCount
			// if(dg.SelectedIndex > dg.PageCount)	dg.SelectedIndex = dg.PageCount;
			BindDetails();
			System.Diagnostics.Debug.WriteLine("(Details)PageIndexChanged Event fired..");
		}

		public int DetailsPageIndexProp
		{
			get
			{
				object obj = ViewState["DetailsPageIndex"];
				return (obj==null) ? 0 : (int)obj;
			}
			set
			{
				ViewState["DetailsPageIndex"] = value;
			}
		}

		public int DetailsSelectedIndexProp
		{
			get
			{
				object obj = ViewState["DetailsSelectedIndex"];
				return (obj==null) ? 0 : (int)obj;
			}
			set
			{
				ViewState["DetailsSelectedIndex"] = value;
			}
		}

		public DataGridEventArgs2 DataGridEventArgsProp
		{
			get
			{
				object obj = ViewState["DataGridEventArgs"];
				return (obj==null) ? null : (DataGridEventArgs2)obj;
			}
			set
			{
				ViewState["DataGridEventArgs"] = value;
			}
		}

	}
}
