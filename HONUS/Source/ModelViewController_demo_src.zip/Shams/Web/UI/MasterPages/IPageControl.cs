#region Copyright(C) M.Shams Mukhtar (shams_mukhtar@yahoo.com)
//
// You are free to use or modify the code, as long as you place
// copyright notice above. Thanks!
//
// Filename: IPageControl.cs
#endregion


#region Instructions

#endregion

#region Remarks
#endregion

#region Namespaces used
	using System;
	using System.Web.UI;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
#endregion

namespace Shams.Web.UI.MasterPages
{
	/// <summary>
	/// IPageControl, basic interface for the PageControlBase
	/// </summary>
	/// <remarks>
	/// 
	/// </remarks>
	/// <seealso cref="PageControlBase"/>
	
	public interface IPageControl
	{
		System.Web.UI.Control ParentControl();

		void HtmlRenderStarts();
		void PreHtmlRender();
		void HtmlRender();
		void PostHtmlRender();
		void HtmlRenderEnds();

		/// <summary>
		/// The title page can be set with this property
		/// </summary>
		string PageTitle
		{
			get; 
			set;
		}
		/// <summary>
		/// MetaInfo Property, used to access/change the metainfo for the inner-Html
		/// </summary>
		string MetaInfo
		{
			get; 
			set;
		}
	}

	/// <summary>
	/// IPlaceHolders, basic interface for the MasterPageBase
	/// </summary>
	/// <remarks>
	/// Provides basic template for proper insertions of the placeholders
	/// </remarks>
	/// <seealso cref="MasterPageBase"/>
	/// 
	public interface IPlaceHolders
	{
		System.Web.UI.Control ParentControl();

		void PreInitialize(EventArgs e);
		void AddPlaceHolderHeader();
		void AddPlaceHolderLogo();
		void AddPlaceHolderMenu();
		void AddPlaceHolderSubMenu();
		void AddPlaceHolderNavigation();
		void AddPlaceHolderContents();
		void AddPlaceHolderSiteCounter();
		void AddPlaceHolderFooter();	
		void PostInitialize(EventArgs e);
	}

	/// <summary>
	/// IPageControlAttributes, basic interface for the PageUserControlBase
	/// </summary>
	/// <remarks>
	/// Provides basic template for Attributes Access
	/// </remarks>
	/// <seealso cref="PageUserControlBase"/>
	public interface IPageControlAttributes
	{
		System.Web.UI.Control ParentControl();

		Panel PanelMain
		{
			get; 
		}
		
		PlaceHolder PlaceHolderLogo
		{
			get; 
		}
		PlaceHolder PlaceHolderHeader
		{
			get; 
		}
		PlaceHolder PlaceHolderMenu
		{
			get; 
		}
		PlaceHolder PlaceHolderSubMenu
		{
			get; 
		}
		PlaceHolder PlaceHolderNavigation
		{
			get; 
		}
		PlaceHolder PlaceHolderContents
		{
			get; 
		}
		PlaceHolder PlaceHolderFooter
		{
			get; 
		}
		PlaceHolder PlaceHolderSiteCounter
		{
			get; 
		}
	}
}
