#region Copyright(C) M.Shams Mukhtar (shams_mukhtar@yahoo.com)
//
// You are free to use or modify the code, as long as you place
// copyright notice above. Thanks!
//
// Filename: default.aspx.cs
#endregion

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Shams.MVC.WebApp
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class DefaultPage : Shams.MVC.WebApp.MasterPage
	{
		// protected System.Web.UI.WebControls.Panel MasterMainPanel;
		// protected Shams.MVC.WebApp.WebUserControls.WebMainContentsUserControl WebUserControl;

		override protected void PageLoad(object sender, System.EventArgs e)
		{
			//Response.Redirect("WebForm1.aspx");
			// Put user code to initialize the page here
		}

		override public void PreInitialize(EventArgs e)
		{
			base.PreInitialize(e);
		}

		override protected void CreateChildControls() 
		{	
			base.CreateChildControls();
		}

		private void InitializeComponent()
		{
		
		}

		override public void AddPlaceHolderContents()
		{
			//userPageControl.PlaceHolderContents.Controls.Add(MasterMainPanel);
			UserControl WebUserControl = LoadUserControl("WebUserControls/UcMasterDetailFrame.ascx");
			userPageControl.PlaceHolderContents.Controls.Add(WebUserControl);
		}

		override public void AddPlaceHolderFooter()
		{
			//userPageControl.PlaceHolderContents.Controls.Add(MasterMainPanel);
			UserControl WebUserControl = LoadUserControl("WebUserControls/FooterControl.ascx");
			userPageControl.PlaceHolderFooter.Controls.Add(WebUserControl);
		}

	}
}
