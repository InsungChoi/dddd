#region Copyright(C) M.Shams Mukhtar (shams_mukhtar@yahoo.com)
//
// You are free to use or modify the code, as long as you place
// copyright notice above. Thanks!
//
// Filename: DataGridEventArgs.cs
#endregion

using System;

namespace Shams.Web.UI.MasterPages
{
	/// <summary>
	/// Summary description for DataGridEventArgs.
	/// </summary>
	[Serializable()]
	public class DataGridEventArgs : EventArgs
	{
		protected int selectedIndex;
		protected int pageIndex;
		protected int pageSize;

		public DataGridEventArgs(int selectedIndex, int pageIndex, int pageSize)
		{
			this.selectedIndex = selectedIndex;
			this.pageIndex = pageIndex;
			this.pageSize = pageSize;
		}
		
		public int SelectedIndexProp
		{
			get
			{
				return selectedIndex;
			}
			set
			{
				selectedIndex = value;
			}
		}
		public int PageIndexProp
		{
			get
			{
				return pageIndex;
			}
			set
			{
				pageIndex = value;
			}
		}

		public int PageSizeProp
		{
			get
			{
				return pageSize;
			}
			set
			{
				pageSize = value;
			}
		}

	}//;~
}
