using System;

namespace Shams.WebApp
{
	/// <summary>
	/// Summary description for MasterPage.
	/// </summary>
	public class MasterPage : Shams.Web.UI.MasterPages.MasterPageBase
	{
		public MasterPage()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		override public void AddPlaceHolderControls()
		{
			// clear place-holders contents from MasterPageBase(.)
			ClearPlaceHolderControls();
			
			// Now call the MasterPageBase:AddPlaceHolderControls(.)
			base.AddPlaceHolderControls();
		}

		override public void AddPlaceHolderHeader()
		{
			System.Web.UI.UserControl userControl = LoadUserControl("WebUserControls/MasterHeaderControl.ascx");
			base.userPageControl.PlaceHolderHeader.Controls.Add(userControl);
		}

		override public void AddPlaceHolderNavigation()
		{
			//System.Web.UI.UserControl userControl = LoadUserControl("WebUserControls/NavigationControl.ascx");
			//base.userPageControl.PlaceHolderNavigation.Controls.Add(userControl);
		}

		override public void AddPlaceHolderLogo()
		{
			System.Web.UI.UserControl userControl = LoadUserControl("WebUserControls/MasterLogoControl.ascx");
			base.userPageControl.PlaceHolderLogo.Controls.Add(userControl);
		}
		override public void AddPlaceHolderContents()
		{
			System.Web.UI.UserControl userControl = LoadUserControl("WebUserControls/MasterContentsControl.ascx");
			base.userPageControl.PlaceHolderContents.Controls.Add(userControl);
		}
	}
}
