#region Copyright(C) M.Shams Mukhtar (shams_mukhtar@yahoo.com)
//
// You are free to use or modify the code, as long as you place
// copyright notice above. Thanks!
//
// Filename: MasterPageFactory.cs
#endregion

#region Instructions
#endregion

#region Remarks
#endregion

#region Namespaces used
	using System;
	using System.Web.UI;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
#endregion

namespace Shams.Web.UI.MasterPages
{
	/// <summary>
	/// Summary description for MasterPageFactory.
	/// </summary>
	public class MasterPageFactory
	{
		public static PageControlBase CreateMasterPageControl()
		{
			return new MasterPageControl();
		}
		
		public static System.Web.UI.Control CreateMasterUserControl(System.Web.UI.Page mainPage)
		{	
			System.Web.UI.Control userControl = null;
			try
			{
				string userControlPtah = System.Configuration.ConfigurationSettings.AppSettings["MasterPageUserControl"];
				userControl = mainPage.LoadControl(userControlPtah);
			}
			catch (Exception ex)
			{
				throw ex;
			}
			return userControl;
		}
	}
}
