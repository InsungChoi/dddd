#region Copyright(C) M.Shams Mukhtar (shams_mukhtar@yahoo.com)
//
// You are free to use or modify the code, as long as you place
// copyright notice above. Thanks!
//
// Filename: Interfaces.cs
#endregion

using System;

namespace Shams.Web.UI.MasterPages
{
	// declare a delegate for the event
	public delegate void NotifyHandler(object sender, EventArgs e);		

	//interface the all listner classes should implement
	public interface IListner 
	{
		void Update(object sender, EventArgs e);
	} //;~ IListner
	
	//interface that all Notifying classes should implement
	public interface INotifier
	{
		void AttachListner(IListner Observer);
		void DetachListner(IListner Observer);
		bool Notify(object sender, EventArgs e);
		bool Notify();
	}  //;~ INotifier
}
