#region (C) Shams Mukhtar
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written permission of the copyright owner.
//
// Filename: PageUserControl.ascx.cs
#endregion

#region Instructions
// Here�s the command to create the library DLL:
// csc /t:library PageUserControl.ascx.cs
// you should place the DLL in wwwroot/bin.
#endregion

#region Remarks
// The UserControl class is associated with files that have .ascx extensions. 
// These files are compiled at run time as UserControl objects and cached in server memory.
// You can nest user controls by declaring one .ascx file in another including the latter in a Web Forms page.
// User controls are contained in ASP.NET Web Forms pages, and offer Web developers an easy way to capture 
// commonly used Web UI. They are instantiated and cached in ways similar to Page objects. Unlike pages, 
// however, user controls cannot be called independently. They can only be called from the page or other 
// user control that contains them. 
// Derive from this class if you want to create a user control using the code-behind technique. 
// This is recommended if you are developing Web Forms pages using this technique.
#endregion

#region Included NameSpaces
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
#endregion

namespace Shams.Web.UI.MasterPages
{
	/// <summary>
	/// Abstract Base for All Page UserControls
	/// </summary>
	public class PageUserControlBase : System.Web.UI.UserControl, IPageControlAttributes
	{
		protected System.Web.UI.WebControls.PlaceHolder placeHolderLogo;
		protected System.Web.UI.WebControls.PlaceHolder placeHolderHeader;
		protected System.Web.UI.WebControls.PlaceHolder placeHolderMenu;
		protected System.Web.UI.WebControls.PlaceHolder placeHolderSubMenu;
		protected System.Web.UI.WebControls.PlaceHolder placeHolderContents;
		protected System.Web.UI.WebControls.PlaceHolder placeHolderFooter;
		protected System.Web.UI.WebControls.PlaceHolder placeHolderNavigation;
		protected System.Web.UI.WebControls.PlaceHolder placeHolderSiteCounter;
		protected System.Web.UI.WebControls.Panel panelMain;
		protected System.Web.UI.WebControls.Image Image2;
		protected System.Web.UI.WebControls.Image ImageHeader;
		protected System.Web.UI.WebControls.Image Image3;
		protected System.Web.UI.WebControls.Image Image4;
		protected System.Web.UI.WebControls.Image Image5;
		protected System.Web.UI.WebControls.Image Image1;
		protected System.Web.UI.WebControls.Image Image6;
		protected System.Web.UI.WebControls.Image Image7;

		public PageUserControlBase() {	}

		virtual protected void InitializeControls()
		{
//			panelMain = new Panel();
//			placeHolderLogo		= new PlaceHolder();
//			placeHolderHeader	= new PlaceHolder();
//			placeHolderMenu		= new PlaceHolder();
//			placeHolderSubMenu	= new PlaceHolder();
//			placeHolderContents = new PlaceHolder();
//			placeHolderFooter	= new PlaceHolder();
//			placeHolderNavigation = new PlaceHolder();
//			placeHolderSiteCounter= new PlaceHolder();

		}
		virtual protected void PageLoad(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			InitializeControls();
		}

		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		private void InitializeComponent()
		{
			this.EnableViewState = true;
			this.Load += new System.EventHandler(this.PageLoad);
		}

		public System.Web.UI.Control ParentControl()
		{
			return this;
		}

		public Panel PanelMain
		{
			get
			{
				return panelMain;
			}
		}
		
		public PlaceHolder PlaceHolderHeader
		{
			get
			{
				return placeHolderHeader;
			}		
		}

		public PlaceHolder PlaceHolderLogo
		{
			get
			{
				return placeHolderLogo;
			}
		}
		public PlaceHolder PlaceHolderMenu
		{
			get
			{
				return placeHolderMenu;
			}
		}
		public PlaceHolder PlaceHolderSubMenu
		{
			get
			{
				return placeHolderSubMenu;
			}
		}
		public PlaceHolder PlaceHolderNavigation
		{
			get
			{
				return placeHolderNavigation;
			}
		}
		public PlaceHolder PlaceHolderContents
		{
			get
			{
				return placeHolderContents;
			}
		}
		public PlaceHolder PlaceHolderFooter
		{
			get
			{
				return placeHolderFooter;
			}
		}
		public PlaceHolder PlaceHolderSiteCounter
		{
			get
			{
				return placeHolderSiteCounter;
			}
		}
	}
}
