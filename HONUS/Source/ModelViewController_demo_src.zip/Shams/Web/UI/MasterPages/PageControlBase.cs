#region Copyright(C) M.Shams Mukhtar (shams_mukhtar@yahoo.com)
//
// You are free to use or modify the code, as long as you place
// copyright notice above. Thanks!
//
// Filename: PageControlBase.cs
#endregion

#region Instructions
#endregion

#region Remarks
#endregion

#region Namespaces used
	using System;
	using System.Web.UI;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
#endregion

#region Bugs
//
// Bug: using INamingContainer...
// by implementing INamingContainer, the MainForm has added the namespace resolution
// that is conflicting in javascript
// <form name="_ctl0:MainForm" method="post" action="Default.aspx" id="_ctl0_MainForm">

//<script language="javascript">
//<!--
//	function __doPostBack(eventTarget, eventArgument) {
//		var theform;
//		if (window.navigator.appName.toLowerCase().indexOf("netscape") > -1) {
//			theform = document.forms["_ctl0:MainForm"];
//		}
//		else {
//			theform = document._ctl0:MainForm;		<================== the cause of bug, javascript!
//		}
//		theform.__EVENTTARGET.value = eventTarget.split("$").join(":");
//		theform.__EVENTARGUMENT.value = eventArgument;
//		theform.submit();
//	}
//// -->
//</script>
// commented out INamingContainer
//
#endregion

namespace Shams.Web.UI.MasterPages
{
	/// <summary>
	/// Summary description for PageControlBase.
	/// </summary>
	public abstract class PageControlBase : System.Web.UI.Control, IPageControl //, INamingContainer
	{
		protected string pageTitle;
		protected string metaInfo;
		protected string styleSheetLink;

		protected HtmlForm htmlForm;

		public PageControlBase()
		{
			pageTitle = "Welcome";
			metaInfo =	@"<meta name='GENERATOR' Content='Microsoft Visual Studio .NET 7.1'>
						<meta name='CODE_LANGUAGE' Content='C#'>
						<meta name=vs_defaultClientScript content='JavaScript'>
						<meta name=vs_targetSchema content='http://schemas.microsoft.com/intellisense/ie5'>
						";
			styleSheetLink=	@"<LINK href='StyleSheet/Style.css' type='text/css' rel='stylesheet'>";
		}

		public static void TestDriver(HtmlTextWriter writer)
		{
			PageControlBase pcb = MasterPageFactory.CreateMasterPageControl();
			pcb.PageRender();
			
			System.Diagnostics.Debug.WriteLine( writer.ToString() );
		}

		public System.Web.UI.Control ParentControl()
		{
			return this;
		}

		public void PageRender()
		{
			HtmlRenderStarts();
			PreHtmlRender();
			HtmlRender();
			PostHtmlRender();
			HtmlRenderEnds();
		}

		public virtual void HtmlRenderStarts()
		{
			this.Controls.AddAt(0, new LiteralControl(@"<!DOCTYPE HTML PUBLIC '-//W3C//DTD HTML 4.0 Transitional//EN'>
				<html>
					<head>
						<title>" + PageTitle + @"</title>" + 
				metaInfo + styleSheetLink + @" 
					" + 
				@"</head>
					<body MS_POSITIONING='GridLayout'>
					" ));
		}

		public virtual void PreHtmlRender()
		{
			// AddTestControl();
		}

		private void AddTestControl()
		{
			this.Controls.Add( new LiteralControl( @"
						<table bgcolor='silver' width='100%'>
							<tr>
								<td colspan=2><h1>Our Page Header</h1></td>
							</tr>
						</table>
						") );
		}

		protected override void CreateChildControls() 
		{
			htmlForm = new HtmlForm();
			htmlForm.ID  = "MainForm";
			htmlForm.Name= "MainForm";
			PageRender();

			base.CreateChildControls();
		}
		
		public virtual void HtmlRender()
		{
			//htmlForm.Controls.Add(this);
			this.Controls.Add(htmlForm);
		}

		public virtual void PostHtmlRender()
		{
		}

		public virtual void HtmlRenderEnds()
		{
			this.Controls.Add(new LiteralControl( @"
					</body>
				</html>") );
		}

		protected override void OnPreRender(EventArgs e)
		{
			htmlForm.ID  = "MainForm";
			htmlForm.Name= "MainForm";
		}

		protected override void Render(HtmlTextWriter writer)
		{
			base.Render(writer);
		}

		public void AddToHtmlForm(Control childControl)
		{
			HtmlPageForm.Controls.Add(childControl);
		}

		public void AddMetaInfo(string meta_info)
		{
			metaInfo += meta_info;
		}

		public virtual string PageTitle
		{
			get
			{
				this.EnsureChildControls();
				string text = (string) ViewState["PageTitle"];
				return (text == null) ? pageTitle : text;
			}
			set
			{
				this.EnsureChildControls();
				ViewState["PageTitle"] = value;
			}
		}

		public virtual string MetaInfo
		{
			get
			{
				this.EnsureChildControls();
				string text = (string) ViewState["MetaInfo"];
				return (text == null) ? metaInfo : text;
			}
			set
			{
				this.EnsureChildControls();
				ViewState["MetaInfo"] = value;
			}
		}

		public virtual string StyleSheetLink
		{
			get
			{
				this.EnsureChildControls();
				string text = (string) ViewState["StyleSheetLink"];
				return (text == null) ? styleSheetLink : text;
			}
			set
			{
				this.EnsureChildControls();
				ViewState["StyleSheetLink"] = value;
			}
		}
		
		public HtmlForm HtmlPageForm
		{
			get
			{
				this.EnsureChildControls();
				return htmlForm;
			}
			set
			{
				this.EnsureChildControls();
				htmlForm = value;
			}
		}
	}
}
