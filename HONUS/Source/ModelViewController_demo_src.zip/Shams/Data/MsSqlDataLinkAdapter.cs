#region Copyright(C) M.Shams Mukhtar (shams_mukhtar@yahoo.com)
//
// You are free to use or modify the code, as long as you place
// copyright notice above. Thanks!
//
// Filename: MsSqlDataLinkAdapter.cs
#endregion

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml;
using System.Xml.Serialization;

namespace Shams.Data
{
	/// <summary>
	/// Data-Access-Object, for MsSql connectivity 
	/// </summary>
	public class MsSqlDataLinkAdapter
	{
		/// <summary>
		/// Read Connection string from the web.config file
		/// </summary>
		/// <param name="csKey"></param>
		/// <returns></returns>
		public static string ReadConfigConnectionString(string csKey)
		{
			string cs = "null";
			try 
			{
				cs = System.Configuration.ConfigurationSettings.AppSettings[csKey];
			}
			catch (Exception ex) 
			{
				System.Diagnostics.Trace.WriteLine(ex);
				throw ex;
			}
			return cs;
		}

		/// <summary>
		/// Create Connection
		/// </summary>
		/// <returns></returns>
		public static SqlConnection Connect(string connect_string)
		{
			SqlConnection oCn = null;

			try 
			{
				System.Diagnostics.Debug.WriteLine(connect_string);
					
				oCn = new SqlConnection(connect_string);	
			}
			catch (SqlException ex) 
			{
				System.Diagnostics.Trace.WriteLine(ex);
			}
			return oCn;
		}

		public static SqlConnection Open(string connect_string)
		{
			SqlConnection oCn = null;
			try 
			{
				System.Diagnostics.Debug.WriteLine(connect_string);

				oCn = new SqlConnection( connect_string );	
				oCn.Open();
			}
			catch (SqlException ex) 
			{
				System.Diagnostics.Trace.WriteLine(ex);
			}
			return oCn;
		}

		public static void Open(SqlConnection oCn)
		{
			try 
			{
				oCn.Open();
			}
			catch (SqlException ex) 
			{
				System.Diagnostics.Trace.WriteLine(ex);
			}
		}

		/// <summary>
		/// Public Disconnect
		/// Purpose: Close and destroy the Connection
		/// </summary>
		/// <param name="oCn"></param>
		/// 		
		public static  void Disconnect(SqlConnection oCn)
		{
			try 
			{
				//--- Close the Connection if the Connection exists
				if ((oCn != null) && (oCn.State != ConnectionState.Closed))
				{
					oCn.Close();
				}

				//--- Destroy the objects and release the memory
				oCn=null;
			}
			catch (SqlException ex) 
			{
				System.Diagnostics.Trace.WriteLine(ex);
				oCn = null;
			}
			finally
			{
				oCn = null;
			}
		}

		public static SqlDataAdapter CreateSqlCommand(SqlConnection oCn, string sql_cmd)
		{
			return CreateSqlCommand(oCn, sql_cmd, CommandType.Text);
		}

		public static SqlDataAdapter CreateSqlCommand(SqlConnection oCn, 
			string sql_cmd, 
			CommandType cmd_type) 
		{
			SqlCommand dbCommand = new SqlCommand(sql_cmd, oCn);		
			dbCommand.CommandType = cmd_type;			
			SqlDataAdapter dbAdapter = new SqlDataAdapter(dbCommand);
			
			return dbAdapter;
		}

		public static DataSet FillDataSet(SqlConnection sqlDbconnection,
			string queryString, 
			string tableName)
		{
			DataSet ds = new DataSet();
			return FillDataSet(ds, sqlDbconnection, queryString, tableName);
		}

		public static DataSet FillDataSet(DataSet ds,
			SqlConnection sqlDbconnection,
			string queryString, 
			string tableName)
		{
			SqlDataAdapter cmd = Shams.Data.MsSqlDataLinkAdapter.CreateSqlCommand(sqlDbconnection, queryString);
			cmd.Fill(ds, tableName);
			return ds;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="conect_string"></param>
		/// <param name="sql_command"></param>
		/// <returns> query_result </returns>
		/// 
		public static int ExecuteDbCommand(string conect_string, string sql_command) 
		{
			SqlConnection oCn = Shams.Data.MsSqlDataLinkAdapter.Connect(conect_string);						
			int query_result = ExecuteDbCommand(oCn, sql_command);
			return query_result;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="oCn"></param>
		/// <param name="sql_command"></param>
		/// <returns></returns>
		/// 
		public static int ExecuteDbCommand(SqlConnection oCn, string sql_cmd) 
		{
			int query_result = 0;
			try
			{
				SqlCommand dbCommand = new SqlCommand(sql_cmd, oCn);		
				Shams.Data.MsSqlDataLinkAdapter.Open(oCn);
				query_result = dbCommand.ExecuteNonQuery();
				
				Shams.Data.MsSqlDataLinkAdapter.Disconnect(oCn);
			}
			catch (SqlException ex) 
			{
				System.Diagnostics.Trace.WriteLine(ex);
				oCn = null;
			}		
			return query_result;
		}

		public static SqlParameter AddParamsToDbCommand(SqlCommand dbCommand, 
			string paramName,
			SqlDbType dbVarType,
			System.Data.ParameterDirection paramDirection,	
			object varValue,
			int varSize) 
		{
			SqlParameter dbParam = new SqlParameter(paramName, dbVarType, varSize);
			dbParam.Direction = paramDirection;
			dbParam.Value = varValue;
			dbParam = dbCommand.Parameters.Add(dbParam);

			return dbParam;
		}
	}
}
