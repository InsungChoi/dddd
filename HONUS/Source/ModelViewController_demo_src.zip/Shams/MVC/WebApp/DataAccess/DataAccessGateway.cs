#region Copyright(C) M.Shams Mukhtar (shams_mukhtar@yahoo.com)
//
// You are free to use or modify the code, as long as you place
// copyright notice above. Thanks!
//
// Filename: DataAccessGateway.cs
#endregion

using System;
using System.Collections;
using System.ComponentModel;
using System.Web;
using System.Web.SessionState;
using System.Data;
using System.Drawing;
using System.Data.SqlClient;	
using Shams.Data;

namespace Shams.MVC.WebApp.DataAccess
{
	/// <summary>
	/// Summary description for DataAccessGateway.
	/// </summary>
	public class DataAccessGateway
	{
		public DataAccessGateway()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public static DataSet GetData1()
		{	
			DataSet contactsDataSet=null;
			try 
			{
				string query_string_customers = 
					"Select CustomerID,CompanyName,ContactName,ContactTitle,Phone,Address from Customers";
				
				string query_string_orders = 
					"Select CustomerID,OrderID,OrderDate,ShippedDate,ShipAddress,Freight from  Orders";

				System.Data.SqlClient.SqlConnection sql_connection = 
					MsSqlDataLinkAdapter.Connect(ConnectStringProp);
				
				contactsDataSet = MsSqlDataLinkAdapter.FillDataSet(sql_connection,
					query_string_customers, 
					"Customers");			
				
				MsSqlDataLinkAdapter.FillDataSet(contactsDataSet,
					sql_connection,
					query_string_orders, 
					"Orders");

				MsSqlDataLinkAdapter.Disconnect(sql_connection);

				// defining the primary keys here! (you could have more than 1 columns as keys!)
				DataColumn[] keys = new DataColumn[1];
				keys[0] = contactsDataSet.Tables[0].Columns[0];		// making this column - primary key!
				contactsDataSet.Tables[0].PrimaryKey = keys;

				// now set for other table!
				keys[0] = contactsDataSet.Tables[1].Columns[0];		// making this for 2nd column - primary key!
				contactsDataSet.Tables[1].PrimaryKey = keys;
			}
			catch (System.Exception ex) 
			{
				System.Diagnostics.Trace.WriteLine(ex.Message);
			}
			return contactsDataSet;
		}

		public static DataSet GetData2()
		{
			DataSet contactsDataSet=null;
			try 
			{
				string query_string_customers = @"Select CustomerID,CompanyName,ContactName,Phone,Address from Customers where CustomerID < 'F'";
				
				// string query_string_orders =  "Select CustomerID,ShipAddress,Freight,ShippedDate from  Orders";
				string query_string_orders = "Select CustomerID,OrderID,OrderDate,ShippedDate,ShipAddress,Freight from  Orders";

				System.Data.SqlClient.SqlConnection sql_connection = MsSqlDataLinkAdapter.Connect(ConnectStringProp);
				contactsDataSet = MsSqlDataLinkAdapter.FillDataSet(sql_connection,
					query_string_customers, 
					"Customers");
				
				MsSqlDataLinkAdapter.FillDataSet(contactsDataSet,
					sql_connection,
					query_string_orders, 
					"Orders");

				contactsDataSet.Relations.Add("Customers",
					contactsDataSet.Tables["Customers"].Columns["CustomerID"],
					contactsDataSet.Tables["Orders"].Columns["CustomerID"]);
				MsSqlDataLinkAdapter.Disconnect(sql_connection);
			}
			catch (System.Exception ex) 
			{
				System.Diagnostics.Trace.WriteLine(ex.Message);
			}

			return contactsDataSet;
		}

		public static DataSet GetData3()
		{	
			DataSet contactsDataSet=null;
			try 
			{
				string query_string_customers = "Select CustomerID,CompanyName,ContactName,ContactTitle,Phone,Address from Customers";
				string query_string_orders = "Select CustomerID,OrderID,OrderDate,ShippedDate,ShipAddress,Freight from  Orders";

				System.Data.SqlClient.SqlConnection sql_connection = MsSqlDataLinkAdapter.Connect(ConnectStringProp);
				contactsDataSet = MsSqlDataLinkAdapter.FillDataSet(sql_connection,
					query_string_customers, 
					"Customers");
				
				MsSqlDataLinkAdapter.FillDataSet(contactsDataSet,
					sql_connection,
					query_string_orders, 
					"Orders");

				contactsDataSet.Relations.Add("Customers",
					contactsDataSet.Tables["Customers"].Columns["CustomerID"],
					contactsDataSet.Tables["Orders"].Columns["CustomerID"]);
				MsSqlDataLinkAdapter.Disconnect(sql_connection);
			}
			catch (System.Exception ex) 
			{
				System.Diagnostics.Trace.WriteLine(ex.Message);
			}

			return contactsDataSet;
		}

		/// <summary>
		/// 
		/// </summary>
		public static string ConnectStringProp
		{
			get
			{
				lock (typeof(DataAccessGateway))
				{
					return MsSqlDataLinkAdapter.ReadConfigConnectionString("ConnectString001");
				}		
			}
		}
	}
}
