#region Copyright(C) M.Shams Mukhtar (shams_mukhtar@yahoo.com)
//
// You are free to use or modify the code, as long as you place
// copyright notice above. Thanks!
//
// Filename: OleDataLinkAdapter.cs
#endregion

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Configuration;
using System.Xml;
using System.Xml.Serialization;

namespace Shams.Data
{
	/// <summary>
	/// Data-Access-Object, for OleDb connectivity 
	/// </summary>
	public class OleDataLinkAdapter
	{
		/// <summary>
		/// Read Connection string from the web.config file
		/// </summary>
		/// <param name="csKey"></param>
		/// <returns></returns>
		public static string ReadConfigConnectionString(string csKey)
		{
			string cs = "null";
			try 
			{
				cs = System.Configuration.ConfigurationSettings.AppSettings[csKey];
			}
			catch (Exception ex) 
			{
				System.Diagnostics.Trace.WriteLine(ex);
				throw ex;
			}
			return cs;
		}

		/// <summary>
		/// Create Connection
		/// </summary>
		/// <returns></returns>
		public static OleDbConnection Connect(string connect_string)
		{
			//lock( typeof( OleDBClientGateWay ) )
			{
				OleDbConnection oCn = null;

				try 
				{
					System.Diagnostics.Debug.WriteLine(connect_string);
					
					oCn = new OleDbConnection(connect_string);	
				}
				catch (OleDbException ex) 
				{
					System.Diagnostics.Trace.WriteLine(ex);
				}
				return oCn;
			}
		}

		public static OleDbConnection Open(string connect_string)
		{
			OleDbConnection oCn = null;
			try 
			{
				System.Diagnostics.Debug.WriteLine(connect_string);

				oCn = new OleDbConnection( connect_string );	
				oCn.Open();
			}
			catch (OleDbException ex) 
			{
				System.Diagnostics.Trace.WriteLine(ex);
			}
			return oCn;
		}

		public static void Open(OleDbConnection oCn)
		{
			try 
			{
				oCn.Open();
			}
			catch (OleDbException ex) 
			{
				System.Diagnostics.Trace.WriteLine(ex);
			}
		}

		/// <summary>
		/// Public Disconnect
		/// Purpose: Close and destroy the Connection
		/// </summary>
		/// <param name="oCn"></param>
		/// 		
		public static  void Disconnect(OleDbConnection oCn)
		{
			try 
			{
				//--- Close the Connection if the Connection exists
				if ((oCn != null) && (oCn.State != ConnectionState.Closed))
				{
					oCn.Close();
				}

				//--- Destroy the objects and release the memory
				oCn=null;
			}
			catch(OleDbException ex) 
			{
				System.Diagnostics.Trace.WriteLine(ex);
				oCn = null;
			}
			finally
			{
				oCn = null;
			}
		}

		public static OleDbDataAdapter CreateOleDbCommand(OleDbConnection oCn, string sql_cmd)
		{
			return CreateOleDbCommand(oCn, sql_cmd, CommandType.Text);
		}

		public static OleDbDataAdapter CreateOleDbCommand(OleDbConnection oCn, 
			string sql_cmd, 
			CommandType cmd_type) 
		{
			//lock( typeof( OleDBClientGateWay ) )
			{
				OleDbCommand odBCommand = new OleDbCommand(sql_cmd, oCn);		
				odBCommand.CommandType = cmd_type;	
			
				//  Now Initialize a new instance of the OleDbDataAdapter class with the 
				// specified OleDbCommand as the SelectCommand property.
				//
				OleDbDataAdapter dbAdapter = new OleDbDataAdapter(odBCommand);
			
				return dbAdapter;
			}
		}

		public static DataSet FillDataSet(OleDbConnection oleDbconnection,
			string queryString, 
			string tableName)
		{
			DataSet ds = new DataSet();
			return FillDataSet(ds, oleDbconnection, queryString, tableName);
		}

		public static DataSet FillDataSet(DataSet ds,
			OleDbConnection oleDbconnection,
			string queryString, 
			string tableName)
		{
			OleDbDataAdapter cmd = Shams.Data.OleDataLinkAdapter.CreateOleDbCommand(oleDbconnection, queryString);
			cmd.Fill(ds, tableName);
			return ds;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="conect_string"></param>
		/// <param name="sql_command"></param>
		/// <returns> query_result </returns>
		/// 
		public static int ExecuteOleDbCommand(string conect_string, string sql_command) 
		{
			OleDbConnection oCn = Shams.Data.OleDataLinkAdapter.Connect(conect_string);						
			int query_result = ExecuteOleDbCommand(oCn, sql_command);
			return query_result;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="oCn"></param>
		/// <param name="sql_command"></param>
		/// <returns></returns>
		/// 
		public static int ExecuteOleDbCommand(OleDbConnection oCn, string sql_command) 
		{
			int query_result = 0;
			try
			{
				OleDbCommand odBCommand = new OleDbCommand(sql_command, oCn);				
				Shams.Data.OleDataLinkAdapter.Open(oCn);
				query_result = odBCommand.ExecuteNonQuery();
				
				Shams.Data.OleDataLinkAdapter.Disconnect(oCn);
			}
			catch(OleDbException ex) 
			{
				System.Diagnostics.Trace.WriteLine(ex);
				oCn = null;
			}		
			return query_result;
		}

		public static OleDbParameter AddParamsToDbCommand(OleDbCommand dbCommand, 
			string paramName,
			OleDbType dbVarType,
			System.Data.ParameterDirection paramDirection,	
			object varValue,
			int varSize) 
		{
			OleDbParameter dbParam = new OleDbParameter(paramName, dbVarType, varSize);
			dbParam.Direction = paramDirection;
			dbParam.Value = varValue;
			dbParam = dbCommand.Parameters.Add(dbParam);

			return dbParam;
		}

	}
}
