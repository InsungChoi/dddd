using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Shams.Web.UI.MasterPages;

namespace Shams.MVC.WebApp.WebUserControls
{
	/// <summary>
	///		Summary description for UcMasterDetails.
	/// </summary>
	public class UcMasterDetails : System.Web.UI.UserControl, 
		Shams.Web.UI.MasterPages.INotifier,
		Shams.Web.UI.MasterPages.IListner
	{
		public event NotifyHandler RaiseEvent;

		protected Shams.MVC.WebApp.WebUserControls.UcMainContentsMaster UcMainContentsMaster1;
		protected Shams.MVC.WebApp.WebUserControls.UcMainContentsDetails UcMainContentsDetails2;
		
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();

			// Make master-detail connections here!

			// Note:>> Simple connections can be made like this...
			// UcMainContentsMaster1.AttachListner(UcMainContentsDetails2);
			
			// For bravity/educational purpose, i am doing it a little different, so that we would
			// know how would we make the same object a listner as well as the notifier...
			//

			UcMainContentsMaster1.AttachListner(this);		// i am the listner
			this.AttachListner(UcMainContentsDetails2);		// attching a listner to myself
			
			base.OnInit(e);
		}
		
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		#region implementation of INotifier
		
		// add the listner
		public void AttachListner(IListner listner)
		{
			RaiseEvent += new NotifyHandler(listner.Update);
		}//Attach

		// remove the listner
		public void DetachListner(IListner listner)
		{
			RaiseEvent -= new NotifyHandler(listner.Update);
		}//Detach

		// comon method to notify all of the listners
		virtual public bool Notify() 
		{
			RaiseEvent(this, EventArgs.Empty);

			return true;
		}// Notify

		// comon method to notify all of the listners
		virtual public bool Notify(object sender, EventArgs e)
		{
			RaiseEvent(sender, e);

			return true;
		}// Notify
		#endregion

		#region implementation of IListner
		virtual public void Update(object sender, EventArgs e)
		{
			// notify this to the listner(s)...
			Notify(sender,e);
		}
		#endregion
	}
}
