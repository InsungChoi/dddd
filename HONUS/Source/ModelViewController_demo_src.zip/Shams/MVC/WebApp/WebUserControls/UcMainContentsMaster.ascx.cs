using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using Shams.Web.UI.MasterPages;
using Shams.MVC.WebApp.DataAccess;

namespace Shams.MVC.WebApp.WebUserControls
{
	/// <summary>
	///		Summary description for UcMainContentsMaster2.
	///		This is not a generic solution...
	///		We are asuming the first column to be the primary key column or so!
	///		
	/// </summary>
	public class UcMainContentsMaster : System.Web.UI.UserControl, Shams.Web.UI.MasterPages.INotifier
	{
		public event NotifyHandler RaiseEvent;
		protected System.Web.UI.WebControls.DataGrid dtgMaster;

		private void Page_Load(object sender, System.EventArgs e)
		{
			if(!Page.IsPostBack)
			{
				if(Cache["ds1"] == null)
				{
					Cache["ds1"] = DataAccessGateway.GetData1();
				}
				// this.DataBind();
				dtgMaster.SelectedIndex = 0;
				MasterSelectedIndexProp = dtgMaster.SelectedIndex;
				MasterPageIndexProp = 0; 
				// notify for the new selection change...
				dtgMasterSelectedIndexChanged(dtgMaster, e);
				return;
			}
			// postBack Scenario...
			dtgMaster.SelectedIndex = MasterSelectedIndexProp;
			dtgMaster.CurrentPageIndex = MasterPageIndexProp;
			this.DataBind();
		}

		private void Page_PreRender(object sender, System.EventArgs e)
		{
		
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();

			// default implementation
			RaiseEvent += new NotifyHandler(this.Nop);
			base.OnInit(e);
		}
		
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.dtgMaster.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.dtgMasterPageIndexChanged);
			this.dtgMaster.DataBinding += new System.EventHandler(this.dtgMasterDataBinding);
			this.dtgMaster.SelectedIndexChanged += new System.EventHandler(this.dtgMasterSelectedIndexChanged);
			this.Load += new System.EventHandler(this.Page_Load);
			this.PreRender += new System.EventHandler(this.Page_PreRender);
		}
		#endregion
		
		#region implementation of INotifier
		
		// add the listner
		public void AttachListner(IListner listner)
		{
			RaiseEvent += new NotifyHandler(listner.Update);
		}//Attach

		// remove the listner
		public void DetachListner(IListner listner)
		{
			RaiseEvent -= new NotifyHandler(listner.Update);
		}//Detach

		// comon method to notify all of the listners
		virtual public bool Notify() 
		{
			RaiseEvent(this, EventArgs.Empty);

			return true;
		}// Notify

		// comon method to notify all of the listners
		virtual public bool Notify(object sender, EventArgs e)
		{
			RaiseEvent(sender, e);

			return true;
		}// Notify

		protected void Nop(object sender, EventArgs e)
		{
			System.Diagnostics.Debug.WriteLine("No Operation");			
		}// Nop

		#endregion


		void BindMaster()
		{
			DataSet ds1 = (DataSet) Cache["ds1"];
			this.dtgMaster.DataSource = ds1.Tables[0].DefaultView;
			System.Diagnostics.Debug.WriteLine("BindMaster(.) called...");
			//this.dtgMaster.SelectedIndex = MasterSelectedIndexProp;
		}

		public void dtgMasterSelectedIndexChanged(object sender, System.EventArgs e)
		{
			DataGrid dg = (DataGrid)sender;
			MasterSelectedIndexProp = dg.SelectedIndex;
			dg.CurrentPageIndex = MasterPageIndexProp;
			this.DataBind();
			
			// Get the Relation key!
			DataView dv = (DataView)dg.DataSource;
			DataTable dt = dv.Table;

			int currentAbsoluteRowIndex = MasterSelectedIndexProp + (MasterPageIndexProp * dg.PageSize);
			
			// bound-limits check		
			if(currentAbsoluteRowIndex < 0) currentAbsoluteRowIndex = 0;
			if(currentAbsoluteRowIndex >= dt.Rows.Count) currentAbsoluteRowIndex = (dt.Rows.Count-1);

			DataRow row = dt.Rows[currentAbsoluteRowIndex];
			
			string strKey = (string)row["CustomerID"];

			// notify the listners...
			this.Notify(sender, new DataGridEventArgs2(strKey));

			System.Diagnostics.Debug.WriteLine("(Master) SelectedIndexChanged Event fired..");
		}

		public void dtgMasterPageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
		{
			DataGrid dg = (DataGrid)source;
			dg.CurrentPageIndex  = e.NewPageIndex;
			MasterPageIndexProp = e.NewPageIndex;
			MasterSelectedIndexProp = dg.SelectedIndex;
			this.DataBind();
			
			// Get the Relation key!
			DataView dv = (DataView)dg.DataSource;
			DataTable dt = dv.Table;

			int currentAbsoluteRowIndex = MasterSelectedIndexProp + (MasterPageIndexProp * dg.PageSize);
			// bound-limits check
			if(currentAbsoluteRowIndex < 0) currentAbsoluteRowIndex = 0;
			if(currentAbsoluteRowIndex >= dt.Rows.Count) currentAbsoluteRowIndex = (dt.Rows.Count-1);

			DataRow row = dt.Rows[currentAbsoluteRowIndex];
			
			string strKey = (string) row["CustomerID"];
			// notify the listners...
			this.Notify(source, new DataGridEventArgs2(strKey));

			System.Diagnostics.Debug.WriteLine("(Master) PageIndexChanged Event fired..");
		}

		private void dtgMasterDataBinding(object sender, System.EventArgs e)
		{
			BindMaster();
		}
		
		public int MasterPageIndexProp
		{
			get
			{
				object obj = ViewState["MasterPageIndex"];
				return (obj==null) ? 0 : (int)obj;
			}
			set
			{
				ViewState["MasterPageIndex"] = value;
			}
		}

		public int MasterSelectedIndexProp
		{
			get
			{
				object obj = ViewState["MasterSelectedIndex"];
				return (obj==null) ? 0 : (int)obj;
			}
			set
			{
				ViewState["MasterSelectedIndex"] = value;
			}
		}
	}
}
