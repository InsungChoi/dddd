using System;
using System.Web;
using System.Web.UI.WebControls; 

namespace Shams.Web.UI.WebControls
{
	public class ExpandCommandColumn : DataGridColumn
	{
		public ExpandCommandColumn()
		{
			ExpandText = "+";
			CollapseText = "-";
		}


		// **********************************************************
		// Gets or sets the text for the item used to expand
		public string ExpandText 
		{
			get {return Convert.ToString(ViewState["ExpandText"]);}
			set {ViewState["ExpandText"] = value;}
		}
		// **********************************************************

		// **********************************************************
		// Gets or sets the text for the item used to collapse
		public string CollapseText 
		{
			get {return Convert.ToString(ViewState["CollapseText"]);}
			set {ViewState["CollapseText"] = value;}
		}
		// **********************************************************

		// **********************************************************
		// Initializes the cells in the column
		public override void InitializeCell(TableCell cell, int columnIndex, ListItemType itemType) 
		{
			base.InitializeCell(cell, columnIndex, itemType);
		}
		public void InitializeCell(TableCell cell, int columnIndex, ListItemType itemType, bool collapsed) 
		{
			base.InitializeCell(cell, columnIndex, itemType);

			if (itemType == ListItemType.Item ||
				itemType == ListItemType.AlternatingItem) 
			{
				LinkButton link = new LinkButton();
				link.CommandName = "Expand";

				if (collapsed)
					link.Text = this.CollapseText;
				else
					link.Text = this.ExpandText;

				link.CausesValidation = false;
				cell.Controls.Add(link);
			}
		}
		// **********************************************************
	}
}
