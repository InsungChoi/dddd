#region Copyright(C) M.Shams Mukhtar (shams_mukhtar@yahoo.com)
//
// You are free to use or modify the code, as long as you place
// copyright notice above. Thanks!
//
// Filename: MasterPageBase.cs
#endregion

#region Instructions
#endregion

#region Remarks
#endregion

#region Namespaces used
	using System;
	using System.Collections;
	using System.ComponentModel;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.SessionState;
	using System.Web.UI;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using System.Configuration;
#endregion

namespace Shams.Web.UI.MasterPages
{
	/// <summary>
	/// MasterPageBase, As the name suggest, its a base class for all the MasterPages
	/// </summary>
	public abstract class MasterPageBase : System.Web.UI.Page, IPlaceHolders
	{
		/// <summary>MasterPageBaseHelper, responsible for All inner HTML stuff</summary>
		protected MasterPageBaseHelper pageController;

		/// <summary>PageUserControlBase, responsible for All Visual stuff</summary>
		protected PageUserControlBase userPageControl;

		/// <summary>
		/// MasterPageBase Constructor
		/// </summary>
		public MasterPageBase()	
		{ 
			pageController = new MasterPageBaseHelper(this);
		}

		virtual protected void PageLoad(object sender, System.EventArgs e)
		{
			// Response.Write("MasterPageBase::Page_Load <BR>");
		}

		override protected void CreateChildControls() 
		{	
			pageController.CreateChildControls();
			PopulateControls();
			AddPlaceHolderControls();	
			base.CreateChildControls();

			this.ChildControlsCreated = true;
		}

		override protected void OnInit(EventArgs e)
		{	
			PreInitialize(e);
			InitializeComponent();
			base.OnInit(e);	
			PostInitialize(e);
		}

		virtual public void PreInitialize(EventArgs e)
		{
			System.Diagnostics.Debug.WriteLine("PreInitialize(e) - Called");

			// shams:>> very important, for loading childs viewstates or so...  
			this.EnsureChildControls();
		}

		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.PageLoad);
		}

		protected void PopulateControls()
		{			
			userPageControl = (PageUserControlBase) LoadPageUserControl();		

			// Add to the form-control embedded in the PageController, userPageControl.
			pageController.AddToHtmlForm(userPageControl);
		}

		protected void ClearChildControls()
		{
			if (this.HasControls())
			{
				for (int i=0; i<this.Controls.Count; ++i)
				{
					this.Controls.Remove(this.Controls[i]);
				}
			}
		}

		protected void AddControlsToPageController()
		{
			if (this.HasControls())
			{
				for (int i=0; i<this.Controls.Count; ++i)
				{
					AddChildControl(this.Controls[i]);
				}
			}
		}
		
		/// <summary>
		/// Override this function if you want Childs of the page added differently
		/// </summary>
		/// <param name="control"></param>
		virtual protected void AddChildControl(System.Web.UI.Control control)
		{
			pageController.AddToHtmlForm(control);
		}
		
		/// <summary>
		/// Override it, if you want to put your-own PageUserControl
		/// </summary>
		virtual protected System.Web.UI.Control LoadPageUserControl()
		{	
			return MasterPageFactory.CreateMasterUserControl(this);
		}

		/// <summary>
		/// Call this to hide the Navigation PlaceHolder
		/// </summary>
		/// <param name="navFlag"></param>
		protected void ToggleNavigation(bool navFlag)
		{
			if (navFlag)
			{
				this.userPageControl.PlaceHolderNavigation.Visible = true;
				this.userPageControl.PlaceHolderSiteCounter.Visible = true;			
			}
			else
			{
				this.userPageControl.PlaceHolderNavigation.Visible = false;
				this.userPageControl.PlaceHolderSiteCounter.Visible = false;			
			}
		}

		protected void ToggleLogoBar(bool navFlag)
		{
			if (navFlag)
			{
				this.userPageControl.PlaceHolderLogo.Visible = true;
			}
			else
			{
				this.userPageControl.PlaceHolderLogo.Visible = false;			
			}
		}

		/// <summary>
		/// Call this function from the derived class to clear the masterPage contents, if any
		/// </summary>
		protected void HidePlaceHolderControls()
		{
			// Hide any existing child controls. (clear destroys the container...)
			this.userPageControl.PlaceHolderLogo.Controls[0].Visible= false;
			this.userPageControl.PlaceHolderHeader.Controls[0].Visible= false;
			this.userPageControl.PlaceHolderMenu.Controls[0].Visible= false;
			this.userPageControl.PlaceHolderSubMenu.Controls[0].Visible= false;
			this.userPageControl.PlaceHolderNavigation.Controls[0].Visible= false;
			this.userPageControl.PlaceHolderContents.Controls[0].Visible= false;
			this.userPageControl.PlaceHolderSiteCounter.Controls[0].Visible= false;
			this.userPageControl.PlaceHolderFooter.Controls[0].Visible= false;
			
			// Clear any previous view state for the existing child controls.
			//ClearChildViewState();
		}

		protected void ClearPlaceHolderControls()
		{
			this.userPageControl.PlaceHolderLogo.Controls.Clear();
			this.userPageControl.PlaceHolderHeader.Controls.Clear();
			this.userPageControl.PlaceHolderMenu.Controls.Clear();
			this.userPageControl.PlaceHolderSubMenu.Controls.Clear();
			this.userPageControl.PlaceHolderNavigation.Controls.Clear();
			this.userPageControl.PlaceHolderContents.Controls.Clear();
			this.userPageControl.PlaceHolderSiteCounter.Controls.Clear();
			this.userPageControl.PlaceHolderFooter.Controls.Clear();
			
			// Clear any previous view state for the existing child controls.
			//ClearChildViewState();
		}

		/// <summary>
		/// Override this function to add controls in place-holders 
		/// </summary>
		virtual public void AddPlaceHolderControls()
		{
			System.Diagnostics.Debug.WriteLine("AddPlaceHolderControls() - Called");

			AddPlaceHolderHeader();
			AddPlaceHolderLogo();
			AddPlaceHolderMenu();
			AddPlaceHolderSubMenu();
			AddPlaceHolderNavigation();
			AddPlaceHolderContents();
			AddPlaceHolderSiteCounter();
			AddPlaceHolderFooter();
		}

		#region IPlaceHolders realizations

		public System.Web.UI.Control ParentControl()
		{
			return this;
		}

		virtual public void AddPlaceHolderHeader()
		{
			System.Diagnostics.Debug.WriteLine("AddPlaceHolderHeader() - Called");
		}
		virtual public void AddPlaceHolderLogo()
		{
			System.Diagnostics.Debug.WriteLine("AddPlaceHolderLogo() - Called");
		}
		virtual public void AddPlaceHolderMenu()
		{
			System.Diagnostics.Debug.WriteLine("AddPlaceHolderMenu() - Called");
		}
		virtual public void AddPlaceHolderSubMenu()
		{
			System.Diagnostics.Debug.WriteLine("AddPlaceHolderSubMenu() - Called");
		}
		virtual public void AddPlaceHolderNavigation()
		{
			System.Diagnostics.Debug.WriteLine("AddPlaceHolderNavigation() - Called");
		}
		virtual public void AddPlaceHolderContents()
		{
			System.Diagnostics.Debug.WriteLine("AddPlaceHolderContents() - Called");
		}
		virtual public void AddPlaceHolderSiteCounter()
		{
			System.Diagnostics.Debug.WriteLine("AddPlaceHolderSiteCounter() - Called");
		}
		virtual public void AddPlaceHolderFooter()
		{
			System.Diagnostics.Debug.WriteLine("AddPlaceHolderFooter() - Called");			
		}
		virtual public void PostInitialize(EventArgs e)
		{
			System.Diagnostics.Debug.WriteLine("PostInitialize(e) - Called");
		}
	
		#endregion


		private void AddPageControlsToHtmlForm(HtmlForm htmlForm)
		{
			System.Web.UI.Control currentPageControl = null;
			IEnumerator controlsIterator = this.Controls.GetEnumerator();
			// skip the first one...
			controlsIterator.MoveNext();	
			// iterate through whole list...
			while (controlsIterator.MoveNext())
			{
				currentPageControl = (System.Web.UI.Control)controlsIterator.Current;
				htmlForm.Controls.Add(currentPageControl);
				this.Controls.Remove(currentPageControl);
			}
		}

		protected System.Web.UI.UserControl LoadUserControl(string urlUserControl)
		{	
			System.Web.UI.UserControl userControl = null;
			try
			{
				userControl = (System.Web.UI.UserControl)Page.LoadControl(urlUserControl);
			}
			catch (Exception ex)
			{
				throw ex;
			}		
			return userControl;
		}
	}
}
