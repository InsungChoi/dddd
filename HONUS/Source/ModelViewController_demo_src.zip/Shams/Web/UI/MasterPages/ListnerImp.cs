#region Copyright(C) M.Shams Mukhtar (shams_mukhtar@yahoo.com)
//
// You are free to use or modify the code, as long as you place
// copyright notice above. Thanks!
//
// Filename: ListnerImp.cs
#endregion

using System;

namespace Shams.Web.UI.MasterPages
{
	/// <summary>
	/// Summary description for ListnerImp.
	/// </summary>
	public class ListnerImp : IListner
	{
		public ListnerImp()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		virtual public void Update(object sender, EventArgs e)
		{
			System.Diagnostics.Debug.WriteLine(e.ToString());
		}
	}
}
