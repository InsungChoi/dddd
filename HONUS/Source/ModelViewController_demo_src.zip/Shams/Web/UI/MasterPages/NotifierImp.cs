#region Copyright(C) M.Shams Mukhtar (shams_mukhtar@yahoo.com)
//
// You are free to use or modify the code, as long as you place
// copyright notice above. Thanks!
//
// Filename: NotifierImp.cs
#endregion

using System;

namespace Shams.Web.UI.MasterPages
{
	/// <summary>
	/// Summary description for NotifierImp.
	/// </summary>
	public class NotifierImp : INotifier
	{
		public event NotifyHandler RaiseEvent;

		public NotifierImp()
		{
			// default implementation
			RaiseEvent += new NotifyHandler(this.Nop);
		}
		// add the listner
		public void AttachListner(IListner listner)
		{
			RaiseEvent += new NotifyHandler(listner.Update);
		}//Attach

		// remove the listner
		public void DetachListner(IListner listner)
		{
			RaiseEvent -= new NotifyHandler(listner.Update);
		}//Detach

		// comon method to notify all of the listners
		virtual public bool Notify() 
		{
			RaiseEvent(this, null);

			return true;
		}// Notify
		
		// comon method to notify all of the listners
		virtual public bool Notify(object sender, EventArgs e)
		{
			RaiseEvent(sender, e);
			return true;
		}// Notify

		protected void Nop(object sender, EventArgs e)
		{
			System.Diagnostics.Debug.WriteLine("No Operation");			
		}// Nop
	}
}
  