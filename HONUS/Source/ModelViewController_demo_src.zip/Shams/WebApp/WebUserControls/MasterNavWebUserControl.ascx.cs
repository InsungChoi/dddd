namespace Shams.WebApp.WebUserControls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;

	/// <summary>
	///		Summary description for MasterNavWebUserControl.
	/// </summary>
	public class MasterNavWebUserControl : System.Web.UI.UserControl
	{
		protected Infragistics.WebUI.UltraWebListbar.UltraWebListbar UltraWebListbar3;
		protected Infragistics.WebUI.UltraWebNavigator.UltraWebMenu Ultrawebmenu2;

		private void Page_Load(object sender, System.EventArgs e)
		{
//			Infragistics.WebUI.UltraWebNavigator.Items items = UltraWebMenu1.Items[4].Items[0].Items;
//			items[0].Tag = "Red";
//			items[1].Tag = "Green";
//			items[2].Tag = "Blue";
//			items[3].Tag = "White";
//			items[4].Tag = "Yellow";
//			items = Ultrawebmenu2.Items[4].Items[0].Items;
//			items[0].Tag = "Red";
//			items[1].Tag = "Green";
//			items[2].Tag = "Blue";
//			items[3].Tag = "White";
//			items[4].Tag = "Yellow";
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
