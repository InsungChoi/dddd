#region Copyright(C) M.Shams Mukhtar (shams_mukhtar@yahoo.com)
//
// You are free to use or modify the code, as long as you place
// copyright notice above. Thanks!
//
// Filename: MasterPageControl.cs
#endregion

#region Instructions

#endregion

#region Remarks
#endregion

using System;

namespace Shams.Web.UI.MasterPages
{
	/// <summary>
	/// Summary description for MasterPageControl.
	/// </summary>
	public class MasterPageControl : PageControlBase
	{
		public MasterPageControl() : base() { }
	}
}
