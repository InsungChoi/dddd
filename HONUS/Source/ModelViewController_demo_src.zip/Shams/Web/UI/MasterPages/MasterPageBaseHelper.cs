#region Copyright(C) M.Shams Mukhtar (shams_mukhtar@yahoo.com)
//
// You are free to use or modify the code, as long as you place
// copyright notice above. Thanks!
//
// Filename: MasterPageBaseHelper.cs
#endregion

#region Instructions
#endregion

#region Remarks
#endregion

#region Namespaces used
using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
#endregion

namespace Shams.Web.UI.MasterPages
{
	/// <summary>
	/// Summary description for MasterPageBaseHelper.
	/// </summary>
	public class MasterPageBaseHelper : IPageControl
	{
		protected System.Web.UI.Page parentPageBase;
		protected string pageTitle;
		protected string metaInfo;
		protected string styleSheetLink;

		protected HtmlForm htmlForm;

		public MasterPageBaseHelper(System.Web.UI.Page pageBase)
		{
			parentPageBase = pageBase;

			pageTitle = "Welcome";
			metaInfo =	@"<meta name='GENERATOR' Content='Microsoft Visual Studio .NET 7.1'>
						<meta name='CODE_LANGUAGE' Content='C#'>
						<meta name=vs_defaultClientScript content='JavaScript'>
						<meta name=vs_targetSchema content='http://schemas.microsoft.com/intellisense/ie5'>
						";
			styleSheetLink=	@"<LINK href='StyleSheet/Style.css' type='text/css' rel='stylesheet'>";
		}

		public static void TestDriver(HtmlTextWriter writer)
		{
		}

		public System.Web.UI.Control ParentControl()
		{
			return ParentPageBase;
		}

		public void CreateChildControls() 
		{
			BuildHtmlForm();
			PageRender();
		}
		
		public void BuildHtmlForm() 
		{
			htmlForm = new HtmlForm();
			htmlForm.ID  = "MainForm";
			htmlForm.Name= "MainForm";
			for(int i=0; i < ParentPageBase.Controls.Count; ++i)
			{
				htmlForm.Controls.Add(ParentPageBase.Controls[i]);
			}
		}

		public void PageRender()
		{
			PreHtmlRender();
			HtmlRenderStarts();
			HtmlRender();
			HtmlRenderEnds();
			PostHtmlRender();
		}

		public virtual void HtmlRenderStarts()
		{
			ParentPageBase.Controls.Add(new LiteralControl(@"<!DOCTYPE HTML PUBLIC '-//W3C//DTD HTML 4.0 Transitional//EN'>
				<html>
					<head>
						<title>" + PageTitle + @"</title>" + 
				metaInfo + styleSheetLink + @" 
					" + 
				@"</head>
					<body MS_POSITIONING='GridLayout'>
					" ));
		}

		public virtual void PreHtmlRender()
		{
			ParentPageBase.Controls.Clear();
		}

		public virtual void HtmlRender()
		{
			ParentPageBase.Controls.Add(htmlForm);
		}

		public virtual void HtmlRenderEnds()
		{
			ParentPageBase.Controls.Add(new LiteralControl( @"
					</body>
				</html>") );
		}

		public virtual void PostHtmlRender()
		{
		}

		public void AddToHtmlForm(Control childControl)
		{
			HtmlPageForm.Controls.Add(childControl);
		}

		public void AddMetaInfo(string meta_info)
		{
			metaInfo += meta_info;
		}

		public virtual string PageTitle
		{
			get
			{
				return pageTitle;
			}
			set
			{
				pageTitle = value;
			}
		}

		public virtual string MetaInfo
		{
			get
			{
				return metaInfo;
			}
			set
			{
				metaInfo = value;
			}
		}

		public virtual string StyleSheetLink
		{
			get
			{
				return styleSheetLink;
			}
			set
			{
				styleSheetLink = value;
			}
		}
		
		public HtmlForm HtmlPageForm
		{
			get
			{
				return htmlForm;
			}
			set
			{
				htmlForm = value;
			}
		}
		public System.Web.UI.Page ParentPageBase
		{
			get
			{
				return this.parentPageBase;
			}
		}
	}
}
